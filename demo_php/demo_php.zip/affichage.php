<?php
function pageHeader($title){
    require 'composants/header.php';
}

function pageFooter(){
    require 'composants/footer.php';
}
?>
