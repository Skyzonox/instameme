<!-- footer.php -->
<footer>
    Footer
</footer>
</body>

</html>